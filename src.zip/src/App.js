import React, { Component } from 'react';
import  Dropdown  from './Dropdown';


class App extends Component {
  render(){
    return(
      <div className="App">
        <Dropdown/>

      </div>
    );
  }
}
export default App;
   

