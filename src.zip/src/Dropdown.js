import React from 'react';


class Dropdown extends React.Component {
    constructor(props) {
      super(props);
      this.state = {value: 'coconut'};
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }
  
    handleChange(event) {    this.setState({value: event.target.value});  }
    handleSubmit(event) {

      event.preventDefault();
    }

    render() {
        return (
          <form onSubmit={this.handleSubmit}>
            <label>
              PICK YOUR FAVOURITE GAME:&nbsp;&nbsp;&nbsp;&nbsp;
              <select value={this.state.value} onChange={this.handleChange}>           
               <option value="HOCKEY">HOCKEY</option>
                <option value="CRICKET">CRICKET</option>
                <option value="FOOTBALL">FOOTBALL</option>
                <option value="TENNIS">TENNIS</option>
              </select>
            </label>&nbsp;&nbsp;&nbsp;
            <input type="submit" value="Submit" />&nbsp;&nbsp;&nbsp;
            <input type="text" />
          </form>
        );
      }
    }

export default Dropdown;
